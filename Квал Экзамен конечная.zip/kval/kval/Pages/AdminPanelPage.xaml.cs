﻿using kval.Classes;
using System;
using System.Windows;
using System.Windows.Controls;

namespace kval.Pages
{
    public partial class AdminPanelPage : Page
    {
        private AuthService authService = new AuthService();

        public AdminPanelPage()
        {
            InitializeComponent();
            Loaded += AdminPanelPage_Loaded;
        }

        private void AdminPanelPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Загружаем информацию о пользователе
            var currentUser = Application.Current.Properties["CurrentUser"] as User;
            if (currentUser != null)
            {
                lblUserInfo.Text = $"Пользователь: {currentUser.FullName} ({currentUser.Role})";
            }

            // Загружаем список пользователей
            LoadUsers();
        }

        private void LoadUsers()
        {
            try
            {
                var users = authService.GetAllUsers();
                dgUsers.ItemsSource = users;
                lblStatus.Text = $"Загружено пользователей: {users.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки пользователей: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnRefreshUsers_Click(object sender, RoutedEventArgs e)
        {
            LoadUsers();
        }

        private void BtnAddUser_Click(object sender, RoutedEventArgs e)
        {
            // Переключаемся на вкладку добавления
            foreach (TabItem tab in ((TabControl)((Grid)Content).Children[1]).Items)
            {
                if (tab.Header.ToString() == "Добавить пользователя")
                {
                    tab.IsSelected = true;
                    txtNewUsername.Focus();
                    break;
                }
            }
        }

        private void BtnAddNewUser_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем ошибки
            lblAddError.Text = "";
            lblAddError.Visibility = Visibility.Collapsed;

            string username = txtNewUsername.Text.Trim();
            string password = txtNewPassword.Password;
            string fullName = txtNewFullName.Text.Trim();
            string email = txtNewEmail.Text.Trim(); // Получаем email из текстового поля
            string role = (cbRole.SelectedItem as ComboBoxItem)?.Content.ToString();

            // Валидация
            if (string.IsNullOrEmpty(username))
            {
                ShowAddError("Логин обязателен для заполнения");
                txtNewUsername.Focus();
                return;
            }

            if (string.IsNullOrEmpty(password))
            {
                ShowAddError("Пароль обязателен для заполнения");
                txtNewPassword.Focus();
                return;
            }

            if (string.IsNullOrEmpty(fullName))
            {
                ShowAddError("ФИО обязательно для заполнения");
                txtNewFullName.Focus();
                return;
            }

            if (password.Length < 6)
            {
                ShowAddError("Пароль должен быть не менее 6 символов");
                txtNewPassword.Focus();
                return;
            }

            // Email не обязателен, но если введен - проверяем формат
            if (!string.IsNullOrEmpty(email))
            {
                // Простая проверка email
                if (!email.Contains("@") || !email.Contains("."))
                {
                    ShowAddError("Некорректный формат email");
                    txtNewEmail.Focus();
                    return;
                }
            }

            // Добавляем пользователя с email (5 параметров!)
            string errorMessage;
            bool success = authService.AddUser(username, password, fullName,
                                             email, role, out errorMessage);

            if (success)
            {
                MessageBox.Show("Пользователь успешно добавлен!", "Успех",
                               MessageBoxButton.OK, MessageBoxImage.Information);

                // Очищаем поля
                txtNewUsername.Text = "";
                txtNewPassword.Password = "";
                txtNewFullName.Text = "";
                txtNewEmail.Text = ""; // Очищаем email поле
                cbRole.SelectedIndex = 1; // По умолчанию "Пользователь"

                // Обновляем список
                LoadUsers();

                // Переключаемся на вкладку пользователей
                foreach (TabItem tab in ((TabControl)((Grid)Content).Children[1]).Items)
                {
                    if (tab.Header.ToString() == "Пользователи")
                    {
                        tab.IsSelected = true;
                        break;
                    }
                }
            }
            else
            {
                ShowAddError(errorMessage);
            }
        }

        private void BtnUnblockUser_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag != null)
            {
                int userId = (int)button.Tag;

                string errorMessage;
                bool success = authService.UnblockUser(userId, out errorMessage);

                if (success)
                {
                    MessageBox.Show("Пользователь разблокирован", "Успех",
                                   MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadUsers();
                }
                else
                {
                    MessageBox.Show(errorMessage, "Ошибка",
                                   MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void BtnResetPassword_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag != null)
            {
                int userId = (int)button.Tag;
                MessageBox.Show($"Сброс пароля для пользователя ID: {userId}\n" +
                              "Функция сброса пароля будет реализована в следующей версии.",
                              "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем данные пользователя
            Application.Current.Properties.Remove("CurrentUser");

            // Возвращаемся на страницу авторизации
            NavigationService.Navigate(new LoginPage());
        }

        private void ShowAddError(string message)
        {
            lblAddError.Text = message;
            lblAddError.Visibility = Visibility.Visible;
        }
    }
}