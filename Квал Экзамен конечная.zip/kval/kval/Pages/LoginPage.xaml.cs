﻿using kval.Classes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace kval.Pages
{
    public partial class LoginPage : Page
    {
        private AuthService authService = new AuthService();
        private User currentUser;

        public LoginPage()
        {
            InitializeComponent();
            Loaded += LoginPage_Loaded;

        }

        private void LoginPage_Loaded(object sender, RoutedEventArgs e)
        {
            txtUsername.Focus();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем предыдущие ошибки
            lblError.Visibility = Visibility.Collapsed;
            lblError.Text = "";

            string username = txtUsername.Text.Trim();
            string password = txtPassword.Password;

            // Проверка обязательных полей
            if (string.IsNullOrEmpty(username))
            {
                ShowError("Поле 'Логин' обязательно для заполнения");
                txtUsername.Focus();
                return;
            }

            if (string.IsNullOrEmpty(password))
            {
                ShowError("Поле 'Пароль' обязательно для заполнения");
                txtPassword.Focus();
                return;
            }

            // Аутентификация
            string errorMessage;
            currentUser = authService.Login(username, password, out errorMessage);

            if (currentUser == null)
            {
                // Показываем ошибку
                ShowError(errorMessage);
                return;
            }

            // Успешный вход
            MessageBox.Show("Вы успешно авторизовались!",
                          "Успех",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);

            // Сохраняем пользователя
            Application.Current.Properties["CurrentUser"] = currentUser;

            // Проверка необходимости смены пароля
            if (currentUser.MustChangePassword)
            {
                // Переходим на страницу смены пароля
                NavigationService.Navigate(new ChangePasswordPage(currentUser.Id));
            }
            else
            {
                // Переходим на главную страницу в зависимости от роли
                if (currentUser.Role == "Администратор")
                {
                    NavigationService.Navigate(new AdminPanelPage());
                }
                else
                {
                    NavigationService.Navigate(new UserPanelPage());
                }
            }
        }

        private void ShowError(string message)
        {
            lblError.Text = message;
            lblError.Visibility = Visibility.Visible;
        }



    }
}