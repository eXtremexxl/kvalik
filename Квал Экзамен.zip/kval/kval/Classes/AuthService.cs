﻿using kval.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace kval.Classes
{
    public class AuthService
    {
        private kvEntities db = new kvEntities();

        // Аутентификация
        public User Login(string username, string password, out string errorMessage)
        {
            errorMessage = string.Empty;

            try
            {
                // Поиск пользователя
                var dbUser = db.Users
                    .Include("Roles")
                    .FirstOrDefault(u => u.username == username && u.is_active == true);

                if (dbUser == null)
                {
                    errorMessage = "Пользователь не найден";
                    return null;
                }

                // Проверка блокировки
                if (dbUser.is_blocked)
                {
                    errorMessage = "Вы заблокированы. Обратитесь к администратору";
                    return null;
                }

                // Проверка пароля
                string inputHash = HashPassword(password);
                if (dbUser.password_hash != inputHash)
                {
                    // Увеличиваем счетчик неудачных попыток
                    dbUser.failed_login_attempts++;

                    if (dbUser.failed_login_attempts >= 3)
                    {
                        dbUser.is_blocked = true;
                        errorMessage = "Аккаунт заблокирован после 3 неудачных попыток";
                    }
                    else
                    {
                        errorMessage = "Неверный пароль. Осталось попыток: " +
                                     (3 - dbUser.failed_login_attempts);
                    }

                    db.SaveChanges();
                    return null;
                }

                // Проверка блокировки по времени (30 дней)
                DateTime? lastLogin = dbUser.last_login_date ?? dbUser.created_at;
                if ((DateTime.Now - lastLogin.Value).TotalDays > 30)
                {
                    dbUser.is_blocked = true;
                    db.SaveChanges();
                    errorMessage = "Учетная запись заблокирована из-за неактивности более 1 месяца";
                    return null;
                }

                // Успешный вход
                dbUser.failed_login_attempts = 0;
                dbUser.last_login_date = DateTime.Now;
                db.SaveChanges();

                return new User
                {
                    Id = dbUser.id,
                    Username = dbUser.username,
                    FullName = dbUser.full_name,
                    Role = dbUser.Roles?.role_name ?? "Пользователь",
                    IsBlocked = dbUser.is_blocked,
                    MustChangePassword = dbUser.must_change_password,
                    LastLoginDate = dbUser.last_login_date
                };
            }
            catch (Exception ex)
            {
                errorMessage = $"Ошибка: {ex.Message}";
                return null;
            }
        }

        // Смена пароля
        public bool ChangePassword(int userId, string currentPassword,
                                 string newPassword, out string errorMessage)
        {
            errorMessage = string.Empty;

            try
            {
                var user = db.Users.Find(userId);
                if (user == null)
                {
                    errorMessage = "Пользователь не найден";
                    return false;
                }

                // Проверка текущего пароля
                string currentHash = HashPassword(currentPassword);
                if (user.password_hash != currentHash)
                {
                    errorMessage = "Текущий пароль неверен";
                    return false;
                }

                // Валидация нового пароля
                if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 6)
                {
                    errorMessage = "Новый пароль должен быть не менее 6 символов";
                    return false;
                }

                // Сохранение
                user.password_hash = HashPassword(newPassword);
                user.password_changed_date = DateTime.Now;
                user.must_change_password = false;

                db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                errorMessage = $"Ошибка: {ex.Message}";
                return false;
            }
        }

        // Хеширование пароля (SHA256 с Base64)
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Преобразуем пароль в байты
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));

                // Конвертируем в Base64 строку
                return Convert.ToBase64String(bytes);
            }
        }

        // Добавление пользователя с email
        public bool AddUser(string username, string password, string fullName,
                          string email, string roleName, out string errorMessage)
        {
            errorMessage = string.Empty;

            try
            {
                // Проверка существования логина
                if (db.Users.Any(u => u.username == username))
                {
                    errorMessage = "Пользователь с таким логином уже существует";
                    return false;
                }

                // Валидация email
                if (!string.IsNullOrEmpty(email) && !IsValidEmail(email))
                {
                    errorMessage = "Некорректный формат email";
                    return false;
                }

                // Получение роли
                var role = db.Roles.FirstOrDefault(r => r.role_name == roleName);
                if (role == null)
                {
                    errorMessage = "Роль не найдена";
                    return false;
                }

                // Хеширование пароля
                string hashedPassword = HashPassword(password);

                // Создание пользователя
                var newUser = new kval.Models.Users
                {
                    username = username,
                    password_hash = hashedPassword,
                    full_name = fullName,
                    email = email,
                    role_id = role.id,
                    is_active = true,
                    is_blocked = false,
                    failed_login_attempts = 0,
                    must_change_password = true,
                    created_at = DateTime.Now
                };

                db.Users.Add(newUser);
                db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                errorMessage = $"Ошибка добавления пользователя: {ex.Message}";
                return false;
            }
        }

        // Проверка валидности email
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Простая проверка формата email
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        // Получение всех пользователей (с email)
        public System.Collections.Generic.List<User> GetAllUsers()
        {
            return db.Users
                .Include("Roles")
                .Select(u => new User
                {
                    Id = u.id,
                    Username = u.username,
                    FullName = u.full_name,
                    Email = u.email,  // Добавили Email
                    Role = u.Roles.role_name,
                    IsActive = u.is_active,
                    IsBlocked = u.is_blocked,
                    FailedLoginAttempts = u.failed_login_attempts,
                    LastLoginDate = u.last_login_date,
                    CreatedAt = u.created_at,
                    MustChangePassword = u.must_change_password
                })
                .ToList();
        }

        // Разблокировка пользователя
        public bool UnblockUser(int userId, out string errorMessage)
        {
            errorMessage = string.Empty;

            try
            {
                var user = db.Users.Find(userId);
                if (user == null)
                {
                    errorMessage = "Пользователь не найден";
                    return false;
                }

                user.is_blocked = false;
                user.failed_login_attempts = 0;
                db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                errorMessage = $"Ошибка: {ex.Message}";
                return false;
            }
        }

        // Метод для конвертации всех паролей в хеши (вызови один раз!)
        public void ConvertAllPasswordsToHashes()
        {
            try
            {
                var allUsers = db.Users.ToList();
                int updatedCount = 0;

                foreach (var user in allUsers)
                {
                    // Если пароль не пустой и еще не хешированный
                    if (!string.IsNullOrEmpty(user.password_hash) &&
                        user.password_hash.Length < 44) // Base64 хеш всегда 44 символа
                    {
                        string originalPassword = user.password_hash;
                        string hashedPassword = HashPassword(originalPassword);

                        user.password_hash = hashedPassword;
                        updatedCount++;

                        MessageBox.Show($"Конвертация: {user.username}\n" +
                                      $"Было: {originalPassword}\n" +
                                      $"Стало: {hashedPassword}");
                    }
                }

                db.SaveChanges();
                MessageBox.Show($"Конвертировано паролей: {updatedCount}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка конвертации: {ex.Message}");
            }
        }
    }

    // Класс для удобной работы с пользователем
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
        public bool IsBlocked { get; set; }
        public int FailedLoginAttempts { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool MustChangePassword { get; set; }
    }
}