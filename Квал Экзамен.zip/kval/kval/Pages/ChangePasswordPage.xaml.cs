﻿using kval.Classes;
using System.Windows;
using System.Windows.Controls;

namespace kval.Pages
{
    public partial class ChangePasswordPage : Page
    {
        private int userId;
        private AuthService authService = new AuthService();

        public ChangePasswordPage(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            txtCurrentPassword.Focus();
        }

        private void BtnChange_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем ошибки
            lblError.Visibility = Visibility.Collapsed;
            lblError.Text = "";

            string currentPassword = txtCurrentPassword.Password;
            string newPassword = txtNewPassword.Password;
            string confirmPassword = txtConfirmPassword.Password;

            // Валидация
            if (string.IsNullOrEmpty(currentPassword) ||
                string.IsNullOrEmpty(newPassword) ||
                string.IsNullOrEmpty(confirmPassword))
            {
                ShowError("Все поля обязательны для заполнения");
                return;
            }

            if (newPassword != confirmPassword)
            {
                ShowError("Новый пароль и подтверждение не совпадают");
                txtNewPassword.Focus();
                return;
            }

            if (newPassword.Length < 6)
            {
                ShowError("Новый пароль должен быть не менее 6 символов");
                txtNewPassword.Focus();
                return;
            }

            // Меняем пароль
            string errorMessage;
            bool success = authService.ChangePassword(userId, currentPassword,
                                                     newPassword, out errorMessage);

            if (success)
            {
                MessageBox.Show("Пароль успешно изменен!", "Успех",
                               MessageBoxButton.OK, MessageBoxImage.Information);

                // Получаем пользователя из сохраненных данных
                var currentUser = Application.Current.Properties["CurrentUser"] as User;

                // Переходим на соответствующую страницу
                if (currentUser != null && currentUser.Role == "Администратор")
                {
                    NavigationService.Navigate(new AdminPanelPage());
                }
                else
                {
                    NavigationService.Navigate(new UserPanelPage());
                }
            }
            else
            {
                ShowError(errorMessage);
                txtCurrentPassword.Focus();
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            // Возвращаемся на страницу авторизации
            NavigationService.GoBack();
        }

        private void ShowError(string message)
        {
            lblError.Text = message;
            lblError.Visibility = Visibility.Visible;
        }
    }
}