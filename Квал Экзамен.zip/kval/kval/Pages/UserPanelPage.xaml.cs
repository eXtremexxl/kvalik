﻿using kval.Classes;
using System;
using System.Windows;
using System.Windows.Controls;

namespace kval.Pages
{
    public partial class UserPanelPage : Page
    {
        public UserPanelPage()
        {
            InitializeComponent();
            Loaded += UserPanelPage_Loaded;
        }

        private void UserPanelPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Загружаем информацию о пользователе
            var currentUser = Application.Current.Properties["CurrentUser"] as User;
            if (currentUser != null)
            {
                lblUserInfo.Text = $"Пользователь: {currentUser.FullName}";
                lblWelcome.Text = $"Вы вошли в систему как {currentUser.FullName}.\n" +
                                $"Ваша роль: {currentUser.Role}\n" +
                                $"Последний вход: {currentUser.LastLoginDate?.ToString("dd.MM.yyyy HH:mm") ?? "Не заходил ранее"}";

                lblStatus.Text = $"Статус: {(currentUser.IsBlocked ? "Заблокирован" : "Активен")}";
            }
        }

        private void BtnChangePassword_Click(object sender, RoutedEventArgs e)
        {
            var currentUser = Application.Current.Properties["CurrentUser"] as User;
            if (currentUser != null)
            {
                NavigationService.Navigate(new ChangePasswordPage(currentUser.Id));
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем данные пользователя
            Application.Current.Properties.Remove("CurrentUser");

            // Возвращаемся на страницу авторизации
            NavigationService.Navigate(new LoginPage());
        }
    }
}